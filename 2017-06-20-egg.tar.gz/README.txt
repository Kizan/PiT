Egg Files place here

/usr/local/lib/python2.7/dist-packages
