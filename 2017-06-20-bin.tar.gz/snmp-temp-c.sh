#!/bin/bash
if [ "$1" = "-g" ]
then
echo .1.3.6.1.2.1.25.1.9
echo string

python /usr/local/bin/snmp-temp.py 0x76

fi
exit 0

