#!/usr/bin/python

from Adafruit_BME280 import *
import sys

sensor = BME280(mode=BME280_OSAMPLE_8, address=int(sys.argv[1], 16))

print '{0:0.2f}'.format(sensor.read_humidity())

